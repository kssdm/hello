package com.epam.universities.blog.view;

import java.util.List;

import java.util.Map;

import com.epam.universities.blog.domain.Post;
import com.epam.universities.blog.domain.User;

public class ConsoleBlogView implements BlogView{

	@Override
	public void printFollowed(Map<User, List<Post>> usersPosts) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Post readPost() {
		// TODO Auto-generated method stub
		return null;
	}

}
